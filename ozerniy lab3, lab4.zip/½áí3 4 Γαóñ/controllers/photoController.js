const Photo = require('../models/photo');

exports.getPhotos = async (req, res) => {
    const photos = await Photo.find();
    res.render('photos', { photos });
};

exports.createPhoto = async (req, res) => {
    const { title, description, imageUrl } = req.body;
    const newPhoto = new Photo({ title, description, imageUrl });
    await newPhoto.save();
    res.redirect('/photos');
};

exports.deletePhoto = async (req, res) => {
    await Photo.findByIdAndDelete(req.params.id);
    res.redirect('/photos');
};