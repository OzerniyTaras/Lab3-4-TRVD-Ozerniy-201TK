const mongoose = require('mongoose');

const photoSchema = new mongoose.Schema({
    title: String,
    description: String,
    imageUrl: String
});

const Photo = mongoose.model('Photo', photoSchema);
module.exports = Photo;