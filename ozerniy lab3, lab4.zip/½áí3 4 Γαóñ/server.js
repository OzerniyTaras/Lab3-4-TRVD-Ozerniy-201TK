const express = require('express');
const mustacheExpress = require('mustache-express'); // ✅ Підключення шаблонізатора
const mongoose = require('mongoose');
const path = require('path');
const photoController = require('./controllers/photoController');
const userController = require('./controllers/userController'); // ✅ Додано

const app = express();
const port = 3000;

//Налаштування шаблонізатора Mustache З ПРАВИЛЬНОЮ ПАПКОЮ ДЛЯ PARTIALS
app.engine('mustache', mustacheExpress(__dirname + '/views/partials', '.mustache'));
app.set('view engine', 'mustache');
app.set('views', __dirname + '/views');

//Парсинг форм
app.use(express.urlencoded({ extended: true }));

//Віддача публічних файлів (CSS, картинки)
app.use(express.static(path.join(__dirname, 'public')));

//Підключення до бази MongoDB
mongoose.connect('mongodb://localhost:27017/photoalbum', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

//Маршрути
app.get('/', (req, res) => res.render('index', { title: 'Головна сторінка' }));
app.get('/about', (req, res) => res.render('about'));

app.get('/photos', photoController.getPhotos);
app.post('/photos', photoController.createPhoto);
app.post('/photos/delete/:id', photoController.deletePhoto);

//Маршрути для користувачів
app.get('/users', userController.getUsers);
app.post('/users', userController.createUser);

//Запуск сервера
app.listen(port, () => console.log(`Сервер запущено на http://localhost:${port}`));